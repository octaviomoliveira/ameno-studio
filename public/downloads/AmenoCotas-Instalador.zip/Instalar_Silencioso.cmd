@echo off
chcp 65001 >nul
title Instalador Ameno Cotas - 3ds Max
echo =========================================================
echo   AMENO COTAS - INSTALANDO NO 3DS MAX (2025 / 2026)...
echo =========================================================
start /wait "" "%~dp0Instalar_Ameno_Cotas.exe" --silent
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [OK] Ameno Cotas instalado com sucesso em:
    echo      %APPDATA%\Autodesk\ApplicationPlugins\AmenoTools
    echo.
    echo Abra o 3ds Max e acesse Ameno Tools ^> Cotas.
) else (
    echo.
    echo [ERRO] Nao foi possivel concluir a instalacao automatica.
)
echo.
pause