@echo off
chcp 65001 >nul
title Instalador Ameno Cotas - 3ds Max (2021 a 2026)
echo =========================================================
echo   AMENO COTAS - INSTALANDO NO 3DS MAX (2021 A 2026)...
echo =========================================================
start /wait "" "%~dp0Instalar_Ameno_Cotas.exe" --silent
if %ERRORLEVEL% EQU 0 (
    echo.
    echo [OK] Ameno Cotas instalado com sucesso em:
    echo      %APPDATA%\Autodesk\ApplicationPlugins\AmenoTools
    echo.
    echo Compatibilidade: 3ds Max 2021, 2022, 2023, 2024, 2025 e 2026.
    echo Abra o 3ds Max e acesse Ameno Tools ^> Cotas.
) else (
    echo.
    echo [ERRO] Nao foi possivel concluir a instalacao automatica.
)
echo.
pause